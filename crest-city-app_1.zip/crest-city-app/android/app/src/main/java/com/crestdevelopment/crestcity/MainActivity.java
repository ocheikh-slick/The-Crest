package com.crestdevelopment.crestcity;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
