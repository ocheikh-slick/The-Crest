// Assembles the app's web layer (www/) from web-src/.
// web-src/index.html is the website page (markup + CSS) with an /*APP*/ slot for web-src/app.js.
// Run: npm run build   (then: npx cap sync)
import { readFileSync, writeFileSync, rmSync, mkdirSync, cpSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const src = join(root, "web-src");
const out = join(root, "www");

let page = readFileSync(join(src, "index.html"), "utf8")
  .replace("/*APP*/", () => readFileSync(join(src, "app.js"), "utf8"));

// Bundle the fonts inside the app so text looks right offline (Belleza and Lato, SIL Open Font License).
page = page.replace(/<link rel="preconnect"[^>]*>\n?/g, "").replace(/<link rel="stylesheet" href="https:\/\/fonts\.googleapis\.com[^>]*>\n?/, "");
const fonts = `@font-face{font-family:Belleza;font-weight:400;font-display:swap;src:url(fonts/belleza-latin-400-normal.woff2) format("woff2")}
${[300, 400, 700].map((w) => `@font-face{font-family:Lato;font-weight:${w};font-display:swap;src:url(fonts/lato-latin-${w}-normal.woff2) format("woff2")}`).join("\n")}`;
page = page.replace("/*FONTS*/", fonts);

const cut = page.indexOf("</style>") + "</style>".length;
const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="format-detection" content="telephone=no">
<meta name="theme-color" content="#13294B">
<style>:root{color-scheme:light}body{margin:0;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}input,textarea,code{-webkit-user-select:text;user-select:text}[hidden]{display:none!important}</style>
${page.slice(0, cut)}
</head>
<body>
${page.slice(cut)}
</body>
</html>
`;

rmSync(out, { recursive: true, force: true });
mkdirSync(out, { recursive: true });
for (const d of ["img", "icons", "media", "fonts"]) cpSync(join(src, d), join(out, d), { recursive: true });
writeFileSync(join(out, "index.html"), html);
console.log("www/ built:", (html.length / 1024).toFixed(0) + " KB page");
