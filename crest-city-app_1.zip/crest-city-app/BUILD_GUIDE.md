# CREST CITY app: build and publish guide

This folder is the iOS and Android app for CREST CITY. It is built with Capacitor 8 and uses the same pages as the website crest-city.netlify.app, with extra app features on top:

- a bottom tab bar (Home, Homes, Masterplan, Saved, Contact)
- the phone's native share sheet on every home ("Share")
- a light vibration when a home is saved
- a branded splash screen and app icon
- fonts, photos and pages stored inside the app, so it opens without a connection
- the Android back button moves back through pages
- push notifications, ready to switch on (see step 4)

App ID: `com.crestdevelopment.crestcity`. You can change it in `capacitor.config.json`, `android/app/build.gradle` and in Xcode. Do this before the first store upload, because the stores never allow it to change afterwards.

## 1. Accounts to open (in The Crest's company name)

| Store | Cost | Notes |
|---|---|---|
| Apple Developer Program | $99 per year | Enrol as an organisation (CDG SARL). This needs a free D-U-N-S number from Dun & Bradstreet, which can take a few weeks. |
| Google Play Console | $25 once | Choose an organisation account. It also needs a D-U-N-S number. Organisation accounts can publish directly. New personal accounts must first run a closed test with at least 12 testers for 14 days. |

Both stores also ask for:

- a privacy policy web page
- a support contact
- phone screenshots
- a short description

## 2. Tools on the build computer

- Node.js 20 or newer
- Android Studio (latest), for Android
- A Mac with the latest Xcode, for iOS. Apple only accepts uploads made with a recent Xcode, and that needs a recent macOS.

With no suitable Mac, a cloud build service such as Codemagic or Ionic Appflow can build and upload the iOS app from this folder.

## 3. First build

```bash
npm install
npm run sync        # builds www/ from web-src/ and copies it into android/ and ios/
```

**Android**

```bash
npm run android     # opens Android Studio
```

1. Press Run to test on a phone or emulator.
2. For the store, choose Build > Generate Signed App Bundle and create a signing key.
3. Keep the signing key and its password safe. Every future update must use the same key.

**iOS**

```bash
npm run ios         # opens Xcode
```

1. Select the App target, then Signing & Capabilities, then choose The Crest's team.
2. Run the app on an iPhone or the simulator.
3. For the store, choose Product > Archive, then Distribute App, then App Store Connect.

## 4. Before the Apple review

Apple rejects apps that look like a repackaged website (guideline 4.2). This app already has a native tab bar, share, haptics, offline content and a splash screen. Push notifications strengthen the case further:

1. **Android:** create a Firebase project and put `google-services.json` in `android/app/`.
2. **iOS:** create an APNs key in the Apple Developer account, then add the Push Notifications capability in Xcode.
3. **App code:** in `web-src/index.html`, add `<script>window.CREST_PUSH=true;</script>` before the main script. Then run `npm run sync`.

Also replace the placeholder phone number and email in `web-src/app.js` before submitting.

## 5. Updating the app later

1. Edit the pages in `web-src/`. `index.html` holds the layout and styles, `app.js` holds the content and behaviour, and the photos are in `img/`.
2. Run `npm run sync`.
3. Raise the version number:
   - Android: `versionCode` and `versionName` in `android/app/build.gradle`
   - iOS: Version and Build in Xcode
4. Build and upload again.

To regenerate the icons and splash screens from the `resources/` folder, run `npm run assets`.
