(function () {
  "use strict";
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const img = (n) => "img/" + n + ".jpg";
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const HEART = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M12 20s-7-4.4-9.2-9A5 5 0 0 1 12 6a5 5 0 0 1 9.2 5c-2.2 4.6-9.2 9-9.2 9z"/></svg>';
  const PLAY = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 4.5v15l12-7.5z"/></svg>';
  const PAUSE = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 5h3.5v14H7zM13.5 5H17v14h-3.5z"/></svg>';
  const LARR = '<svg viewBox="0 0 58 16" fill="none" stroke="currentColor" stroke-width="1.2"><path d="M57 8H1M8 1 1 8l7 7"/></svg>';
  const RARR = '<svg viewBox="0 0 58 16" fill="none" stroke="currentColor" stroke-width="1.2"><path d="M1 8h56M50 1l7 7-7 7"/></svg>';

  /* ---------- data ---------- */
  const STATUS = { available: "Available", reserved: "Reserved", sold: "Sold" };
  const SCOL = { available: "#2F7D52", reserved: "#C08A24", sold: "#9C3A3A" };
  const SOLD = ["A03", "A07", "B02", "C05", "D01", "B09"];
  const RES = ["A04", "A10", "A12", "B05", "B06", "C02", "C08", "D04"];
  const ROWS = [
    { r: "A", label: "Row A", n: 13, x0: 315, w: 71.9, y: 58, h: 92 },
    { r: "B", label: "Row B", n: 10, x0: 440, w: 78.5, y: 185, h: 62 },
    { r: "C", label: "Row C", n: 10, x0: 440, w: 78.5, y: 249, h: 86 },
    { r: "D", label: "Row D", n: 5, x0: 908, w: 85, y: 400, h: 74 }
  ];
  const VIMG = ["villa_front", "villa_pair", "villa_street", "villa_close", "villa_cover", "solar", "entrance_villa"];
  const AIMG = ["activity", "commercial", "boulevard", "shopfront", "parking", "pergola"];
  const UNITS = [];
  let k = 0;
  const pad = (n) => String(n).padStart(2, "0");
  ROWS.forEach((R) => {
    for (let i = 1; i <= R.n; i++) {
      const id = R.r + pad(i);
      const s = k++ % VIMG.length;
      UNITS.push({
        id, code: R.r + "-" + pad(i), type: "villa", row: R.r, rowLabel: R.label,
        name: "Villa " + R.r + "-" + pad(i), status: SOLD.includes(id) ? "sold" : RES.includes(id) ? "reserved" : "available",
        rect: { x: R.x0 + (i - 1) * R.w + 3, y: R.y + 3, w: R.w - 6, h: R.h - 6 },
        imgs: VIMG.slice(s).concat(VIMG.slice(0, s)).slice(0, 5), beds: 5, built: 291.2, plot: 295.2
      });
    }
  });
  const APRES = ["AP03", "AP08"], APSOLD = ["AP01"];
  for (let i = 1; i <= 11; i++) {
    const id = "AP" + pad(i), tA = i <= 6, s = (i - 1) % AIMG.length;
    UNITS.push({
      id, code: "AP-" + pad(i), type: "apartment", row: "AP", rowLabel: "Residences",
      name: "Apartment AP-" + pad(i), status: APSOLD.includes(id) ? "sold" : APRES.includes(id) ? "reserved" : "available",
      apType: tA ? "A" : "B", beds: tA ? 3 : null, built: tA ? 127 : 96.7,
      imgs: AIMG.slice(s).concat(AIMG.slice(0, s)).slice(0, 5)
    });
  }
  const byId = (id) => UNITS.find((u) => u.id === id);

  const NEWS = [
    { d: "3 June 2026", t: "Crest Development Group incorporates as CDG SARL", img: "villa_cover", x: "Active in Djibouti since 2024, Crest Development Group is now incorporated as CDG SARL, the company that will deliver CREST CITY.", m: "Incorporation gives buyers, partners and banks a single legal counterpart for the project, from reservation contracts to handover." },
    { d: "August 2026", t: "The CREST CITY masterplan", img: "aerial", x: "38 Signature Villas, apartments, a commercial street and an activity center on a 23,765 m² gated site.", m: "Palm-lined walkways connect every home to the central plaza, the playgrounds and the shops, with visitor parking kept at the edge of the community." },
    { d: "September 2026", t: "Signature Villas, designed around family life", img: "villa_close", x: "Five bedrooms, a majlis, a maid's suite and a foyer at the entrance, over three levels.", m: "Each villa keeps guest and family areas apart, separates the service spaces, and has a private two-car driveway." },
    { d: "September 2026", t: "Solar power for every common area", img: "solar", x: "Rooftop solar supplies the lighting and shared services across CREST CITY.", m: "Solar-powered common areas lower service charges for residents and keep shared spaces running." },
    { d: "Coming soon", t: "News from the site", img: "site", x: "Photos and progress milestones from the site will be published here.", m: "Buyers will also follow the progress of their own home in the buyer portal once construction starts." },
    { d: "Coming soon", t: "The Crest app for buyers and residents", img: "pergola", x: "One app to follow construction, pay installments and, after handover, manage life in the community.", m: "The app will launch on iOS and Android after the website." }
  ];
  const COMM = [
    ["villa_street", "Signature Villas", "38 family homes on quiet avenues", "properties", "villa"],
    ["commercial", "Apartments", "11 homes in two sizes", "properties", "apartment"],
    ["shopfront", "Commercial Street", "Shops, cafés and services", "community", ""],
    ["activity", "Activity Center", "Clubhouse, events and sports", "community", ""],
    ["playground", "Playgrounds", "Shaded play beside the lawns", "community", ""],
    ["pergola", "Gardens & Walkways", "Palm-lined paths to every home", "community", ""],
    ["solar", "Solar Community", "Solar power for the common areas", "community", ""]
  ];

  const SLIDES = [
    ["gate", "A gated community in Djibouti", "Welcome to CREST CITY", "Signature Villas, apartments and a commercial street behind one secure entrance.", "community", "50% 30%", "", "Discover the community"],
    ["villa_front", "Latest launch", "Signature Villas", "Five bedrooms, a majlis and a maid's suite over three levels.", "properties", "50% 50%", "villa", "View villas"],
    ["boulevard", "The heart of the community", "The Central Boulevard", "Palm-lined walkways linking homes, shops and the activity center.", "community", "50% 60%", "", "Explore amenities"],
    ["aerial", "Interactive masterplan", "Find your home", "See every villa and its availability on the masterplan.", "masterplan", "50% 50%", "", "Explore the masterplan"],
    ["solar", "Sustainability", "Powered by the sun", "Solar energy for every common area across CREST CITY.", "about", "50% 40%", "", "About The Crest"]
  ];
  /* ---------- state ---------- */
  let wish = new Set();
  try { const w = JSON.parse(localStorage.getItem("crest-wish") || "[]"); if (Array.isArray(w)) wish = new Set(w.filter(byId)); } catch (e) {}
  const saveWish = () => { try { localStorage.setItem("crest-wish", JSON.stringify([...wish])); } catch (e) {} updWish(); };
  const updWish = () => { ["#wcount", "#tcount"].forEach((q) => { const c = $(q); if (c) { c.textContent = wish.size; c.dataset.n = wish.size; } }); };
  const F = { type: "all", status: "all", row: "all", size: "all", sort: "rec" };
  let mpFilter = "all", mpSel = null, contactUnit = "", cur = "home", paused = false, wasPaused = false;
  const reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- pieces ---------- */
  const eb = (t) => '<div class="eyebrow">' + t + "</div>";
  const st = (s) => '<span class="st ' + s + '">' + STATUS[s] + "</span>";
  const capOf = (u) => u.type === "villa" ? "5 bedrooms · " + u.built + " m² · " + u.rowLabel : (u.beds ? u.beds + " bedrooms · " : "Type " + u.apType + " · ") + u.built + " m² · Residences";
  const ucard = (u) => '<article class="ucard"><div class="m" data-unit="' + u.id + '"><img loading="lazy" src="' + img(u.imgs[0]) + '" alt="' + esc(u.name) + '"><button class="save' + (wish.has(u.id) ? " on" : "") + '" data-heart="' + u.id + '" aria-label="Save ' + esc(u.name) + '">' + HEART + "</button></div>" + st(u.status) + '<h3 data-unit="' + u.id + '">' + esc(u.name) + '</h3><div class="cap">' + capOf(u) + "</div></article>";
  const story = (n) => '<article class="story" data-more><div class="m"><img loading="lazy" src="' + img(n.img) + '" alt=""></div><div class="small">' + n.d + '</div><div class="cap">' + esc(n.t) + '</div><p class="more">' + esc(n.x) + " " + esc(n.m) + "</p></article>";
  const comm = (c) => '<a class="comm" data-go="' + c[3] + '"' + (c[4] ? ' data-type="' + c[4] + '"' : "") + '><div class="m"><img loading="lazy" src="' + img(c[0]) + '" alt=""></div><h3>' + c[1] + '</h3><div class="cap">' + c[2] + "</div></a>";
  const carousel = (id, title, eyebrow, items, extra) => '<section class="sec"><div class="wrap"><div class="head"><div class="l">' + eb(eyebrow) + '<h2 class="h-xl">' + title + "</h2></div>" +
    '<div class="car-nav" data-car="' + id + '"><button data-dir="-1" aria-label="Previous">' + LARR + '</button><button data-dir="1" aria-label="Next">' + RARR + "</button></div></div>" +
    '<div class="track" id="' + id + '">' + items + "</div>" + (extra || "") + "</div></section>";
  const phero = (im, crumb, h) => '<section class="phero"><img src="' + img(im) + '" alt=""><div class="wrap"><div class="crumb">' + crumb + "</div><h1>" + h + "</h1></div></section>";
  const reg = () => '<section class="sec paper"><div class="wrap"><div class="reg">' + eb("Register") + '<h2 class="h-xl">Register your interest</h2><p>Be the first to hear about new releases, payment plans and site visits.</p><a class="btn mt-s" data-go="contact">Get in touch</a></div></div></section>';

  function mapSVG(o) {
    o = o || {};
    let s = '<svg viewBox="0 0 1440 849" preserveAspectRatio="none" aria-label="CREST CITY masterplan">';
    UNITS.filter((u) => u.type === "villa").forEach((u) => {
      const r = u.rect;
      if (o.highlight && o.highlight !== u.id) { s += '<rect x="' + r.x + '" y="' + r.y + '" width="' + r.w + '" height="' + r.h + '" fill="#fff" fill-opacity=".1" stroke="#fff" stroke-opacity=".5" stroke-width="1.2"/>'; return; }
      const dim = o.filter && o.filter !== "all" && u.status !== o.filter;
      s += '<g class="lot' + (dim ? " dim" : "") + (o.sel === u.id || o.highlight === u.id ? " sel" : "") + '" data-lot="' + u.id + '" tabindex="0" role="button" aria-label="Villa ' + u.code + ", " + STATUS[u.status] + '"><rect x="' + r.x + '" y="' + r.y + '" width="' + r.w + '" height="' + r.h + '" fill="' + SCOL[u.status] + '" fill-opacity=".55"/>' +
        (o.labels ? '<text class="lotlbl" x="' + (r.x + r.w / 2) + '" y="' + (r.y + r.h / 2 + 5) + '" text-anchor="middle">' + u.code + "</text>" : "") + "</g>";
    });
    [[215, 470, "ACTIVITY CENTER"], [560, 548, "COMMERCIAL STREET"], [795, 452, "CENTRAL PLAZA"], [318, 292, "PLAYGROUND"], [515, 440, "VISITOR PARKING"]].forEach((z) => {
      const w = z[2].length * 11.6 + 26;
      s += '<g pointer-events="none"><rect x="' + (z[0] - w / 2) + '" y="' + (z[1] - 16) + '" width="' + w + '" height="30" fill="#fff" fill-opacity=".92"/><text class="zone" x="' + z[0] + '" y="' + (z[1] + 5) + '" text-anchor="middle" fill="#0A0A0A">' + z[2] + "</text></g>";
    });
    return s + "</svg>";
  }

  /* ---------- pages ---------- */
  const P = {};
  P.home = () => {
    const avail = UNITS.filter((u) => u.status === "available");
    const feat = avail.filter((u) => u.type === "villa").filter((u, i) => i % 3 === 0).slice(0, 5).concat(avail.filter((u) => u.type === "apartment").slice(0, 2));
    return '<section class="slider on-dark" id="hs" aria-roledescription="carousel" aria-label="CREST CITY highlights" tabindex="0">' +
      SLIDES.map((d, i) => '<div class="slide ' + (i % 2 ? "zo" : "zi") + (i === 0 ? " on" : "") + '" style="--ox:' + d[5] + '" aria-hidden="' + (i ? "true" : "false") + '"><div class="ph"><img src="' + img(d[0]) + '" alt="' + esc(d[2]) + '"></div>' +
        '<div class="scap"><div class="wrap"><div class="kick">' + d[1] + '</div><' + (i ? "h2" : "h1") + ' class="stitle">' + d[2] + "</" + (i ? "h2" : "h1") + '><p class="sdesc">' + d[3] + '</p><a class="tlink white" data-go="' + d[4] + '"' + (d[6] ? ' data-type="' + d[6] + '"' : "") + ">" + d[7] + "</a></div></div></div>").join("") +
      '<div class="sl-ui"><div class="wrap"><div class="bars">' + SLIDES.map((d, i) => '<button class="bar' + (i === 0 ? " on" : "") + '" data-sl="' + i + '" aria-label="Show slide ' + (i + 1) + ": " + esc(d[2]) + '"><i></i></button>').join("") +
      '<span class="count"><b id="slc">01</b> / ' + pad(SLIDES.length) + '</span></div><div class="ctrl"><button class="round" data-sdir="-1" aria-label="Previous slide">' + LARR.replace('viewBox="0 0 58 16"', 'viewBox="0 0 58 16" class="ar"') + '</button><button class="round" data-sdir="1" aria-label="Next slide">' + RARR.replace('viewBox="0 0 58 16"', 'viewBox="0 0 58 16" class="ar"') + '</button><button class="round" id="slp" aria-label="Pause slideshow">' + PAUSE + "</button></div></div></div></section>" +
      '<section class="sec intro"><div class="wrap"><h2 class="h-xl">Premium living, planned for Djibouti</h2><div class="body"><p>CREST CITY brings 38 Signature Villas, modern apartments and a commercial street together in one gated, solar-powered community. Palm-lined avenues connect every home to the central plaza, the activity center, the playgrounds and the shops, so daily life stays within a short walk.</p><p>Every home is designed around the way families live in Djibouti, with a majlis for guests, separate family spaces, room for household staff and shade throughout.</p></div>' +
      '<form class="search" id="hsearch"><div class="fld"><label for="hs-type">Property type</label><select id="hs-type"><option value="all">All properties</option><option value="villa">Signature Villas</option><option value="apartment">Apartments</option></select></div>' +
      '<div class="fld"><label for="hs-status">Availability</label><select id="hs-status"><option value="all">Any</option><option value="available">Available</option><option value="reserved">Reserved</option></select></div>' +
      '<div class="fld"><label for="hs-size">Size</label><select id="hs-size"><option value="all">Any size</option><option value="small">Under 130 m²</option><option value="large">290 m² and above</option></select></div>' +
      '<button class="btn" type="submit">Search properties</button></form></div></section>' +
      '<section class="sec"><div class="wrap duo"><div>' + eb("New") + '<h2 class="h-xl">The CREST CITY film</h2><p class="sub">Walk through the community from the comfort of your home.</p><a class="filmcard" data-film><div class="m"><img src="' + img("hero_poster") + '" alt="Villa avenue at CREST CITY"><span class="play">' + PLAY + '</span></div><div class="cap">Signature Villas, the central plaza and the commercial street, seen from the ground and from the air.</div></a></div>' +
      '<div><div class="head" style="margin-bottom:0"><div class="l"><div class="eyebrow" style="visibility:hidden" aria-hidden="true">News</div><h2 class="h-xl">Discover our news</h2></div><a class="tlink" data-go="news">View all</a></div><p class="sub">Milestones, construction progress and community life.</p><div class="pair">' + NEWS.slice(0, 2).map(story).join("") + "</div></div></div></section>" +
      carousel("c-comm", "Life at CREST CITY", "Community", COMM.map(comm).join("")) +
      '<section class="sec paper"><div class="wrap feature"><div class="m"><img loading="lazy" src="' + img("villa_front") + '" alt="Signature Villa"></div><div class="t">' + eb("Latest launch") + '<h2 class="h-xl">Signature Villas</h2><p>Three-level family homes with five bedrooms, three living rooms including a majlis, a maid\'s suite and a private two-car driveway. Four layout options, each designed around Djiboutian family life.</p>' +
      '<dl class="specs"><div><dt>Bedrooms</dt><dd>5</dd></div><div><dt>Built area</dt><dd>291.2 m²</dd></div><div><dt>Plot</dt><dd>295.2 m²</dd></div><div><dt>Levels</dt><dd>Ground, first, attic</dd></div></dl><div class="btns mt-s"><a class="btn" data-go="properties" data-type="villa">View villas</a><a class="btn line" data-go="contact">Book a visit</a></div></div></div></section>' +
      '<section class="banner on-dark"><img loading="lazy" src="' + img("aerial") + '" alt=""><div class="wrap">' + '<div class="eyebrow" style="justify-content:center">Masterplan</div><h2 class="h-xl">Find your home on the masterplan</h2><p>See every villa and its availability, then open the details and book a visit.</p><a class="btn white" data-go="masterplan">Explore the masterplan</a></div></section>' +
      carousel("c-units", "Available now", "Properties", feat.map(ucard).join(""), '<div class="mt-m"><a class="tlink" data-go="properties">All properties</a></div>') + reg();
  };

  P.community = () => {
    const sp = (im, e, h, p, rev, link) => '<section class="sec' + (rev ? " paper" : "") + '"><div class="wrap feature' + (rev ? " rev" : "") + '"><div class="m"><img loading="lazy" src="' + img(im) + '" alt=""></div><div class="t">' + eb(e) + '<h2 class="h-xl">' + h + "</h2><p>" + p + "</p>" + (link || "") + "</div></div></section>";
    const a = (h, p) => "<div><h3>" + h + "</h3><p>" + p + "</p></div>";
    return phero("boulevard", "Community", "Everything you need, behind one gate") +
      '<section class="sec intro"><div class="wrap"><h2 class="h-xl">A complete community</h2><div class="body"><p>CREST CITY brings Signature Villas, apartments, a commercial street and community facilities together on a 23,765 m² gated site. Palm-lined walkways link every home to the central plaza, the playgrounds and the shops.</p></div>' +
      '<div class="stats"><div><b>23,765 m²</b><span>Gated site</span></div><div><b>38</b><span>Signature Villas</span></div><div><b>11</b><span>Apartments</span></div><div><b>100%</b><span>Solar common areas</span></div></div></div></section>' +
      sp("villa_street", "Homes", "Signature Villas", "38 three-level villas on quiet residential avenues, each with five bedrooms, a majlis, a maid's suite and a private driveway.", true, '<a class="tlink" data-go="properties" data-type="villa">View villas</a>') +
      sp("shopfront", "Retail", "Commercial Street", "Shops, cafés and services along a shaded street, with visitor parking close by.", false) +
      sp("activity", "Community", "Activity Center", "A clubhouse for gatherings, classes, events and sports, run for residents and their families.", true) +
      sp("playground", "Families", "Playgrounds and sports", "Children's playgrounds beside open lawns, with sports facilities for every age.", false) +
      sp("pergola", "Outdoors", "Walkways and gardens", "Shaded pergolas, planted gardens and pedestrian paths designed for Djibouti's climate.", true) +
      '<section class="sec"><div class="wrap"><div class="head"><div class="l">' + eb("Amenities") + '<h2 class="h-xl">Built into every day</h2></div></div><div class="amen">' +
      a("Mosque", "A community mosque within walking distance of every home.") + a("Security", "Controlled access at the entrance and integrated security, day and night.") +
      a("Solar energy", "Solar power for lighting and shared services.") + a("Smart homes", "Smart home systems in every villa.") +
      a("Fiber internet", "High-speed fiber across the community.") + a("Visitor parking", "Dedicated parking for guests and shoppers.") +
      a("Sports", "Courts and activity spaces for residents.") + a("Green spaces", "Gardens and palm-lined avenues throughout.") + "</div></div></section>" +
      '<section class="banner on-dark"><img loading="lazy" src="' + img("solar") + '" alt=""><div class="wrap"><div class="eyebrow" style="justify-content:center">Sustainability</div><h2 class="h-xl">Powered by the sun</h2><p>Rooftop solar supplies the common areas across CREST CITY, lowering service charges and keeping shared spaces running.</p></div></section>' + reg();
  };

  function filtered() {
    const L = UNITS.filter((u) => (F.type === "all" || u.type === F.type) && (F.status === "all" || u.status === F.status) && (F.row === "all" || u.row === F.row) && (F.size === "all" || (F.size === "small" ? u.built < 130 : u.built >= 290)));
    const rank = { available: 0, reserved: 1, sold: 2 };
    if (F.sort === "rec") L.sort((a, b) => rank[a.status] - rank[b.status]);
    if (F.sort === "big") L.sort((a, b) => b.built - a.built);
    if (F.sort === "small") L.sort((a, b) => a.built - b.built);
    return L;
  }
  const opt = (v, t, cv) => '<option value="' + v + '"' + (cv === v ? " selected" : "") + ">" + t + "</option>";
  P.properties = () => {
    const L = filtered();
    return phero("villa_pair", "Properties", "Find your home at CREST CITY") +
      '<section class="sec"><div class="wrap"><form class="filters" id="pfilters">' +
      '<div class="fld"><label for="pf-type">Property type</label><select id="pf-type">' + opt("all", "All properties", F.type) + opt("villa", "Signature Villas", F.type) + opt("apartment", "Apartments", F.type) + "</select></div>" +
      '<div class="fld"><label for="pf-status">Availability</label><select id="pf-status">' + opt("all", "Any", F.status) + opt("available", "Available", F.status) + opt("reserved", "Reserved", F.status) + opt("sold", "Sold", F.status) + "</select></div>" +
      '<div class="fld"><label for="pf-row">Location</label><select id="pf-row">' + opt("all", "Anywhere", F.row) + ROWS.map((R) => opt(R.r, "Villas, " + R.label, F.row)).join("") + opt("AP", "Residences", F.row) + "</select></div>" +
      '<div class="fld"><label for="pf-size">Size</label><select id="pf-size">' + opt("all", "Any size", F.size) + opt("small", "Under 130 m²", F.size) + opt("large", "290 m² and above", F.size) + "</select></div>" +
      '<div class="fld"><label for="pf-sort">Sort by</label><select id="pf-sort">' + opt("rec", "Availability", F.sort) + opt("big", "Largest first", F.sort) + opt("small", "Smallest first", F.sort) + opt("num", "Unit number", F.sort) + "</select></div></form>" +
      '<div class="resline"><span class="small">' + L.length + " of " + UNITS.length + ' homes</span><a class="tlink" data-go="masterplan">View on masterplan</a></div>' +
      (L.length ? '<div class="ugrid">' + L.map(ucard).join("") + "</div>" : '<div class="empty"><h3 class="h-l">No homes match these filters</h3><p>Try a different availability or size.</p><button class="btn line" id="pf-reset">Clear filters</button></div>') +
      "</div></section>" + reg();
  };

  P.unit = (id) => {
    const u = byId(id);
    if (!u) return P.properties();
    const v = u.type === "villa";
    const facts = v ? [["Bedrooms", "5"], ["Living rooms", "3, including majlis"], ["Built area", "291.2 m²"], ["Plot", "295.2 m²"], ["Levels", "Ground, first, attic"], ["Parking", "Two-car driveway"], ["Maid's suite", "Yes"], ["Location", u.rowLabel]]
      : [["Type", "Apartment " + u.apType], ["Area", u.built + " m²"], ["Bedrooms", u.beds ? String(u.beds) : "On request"], ["Building", "Two-floor residence"], ["Location", "Residences"], ["Common areas", "Solar powered"]];
    const feats = v ? ["Foyer at the entrance", "Majlis for guests", "Maid's suite with bathroom", "Separate family and guest areas", "Private two-car driveway", "Smart home systems", "Solar-supported air conditioning", "Fiber internet"]
      : ["A short walk to the shops", "Access to all community amenities", "Controlled access, day and night", "Solar-powered common areas", "Fiber internet", "Visitor parking nearby"];
    const sim = UNITS.filter((x) => x.type === u.type && x.id !== u.id && x.status === "available").slice(0, 6);
    const dl = (arr) => '<dl class="specs">' + arr.map((f) => "<div><dt>" + f[0] + "</dt><dd>" + f[1] + "</dd></div>").join("") + "</dl>";
    return '<div class="wrap"><nav class="crumbs"><a data-go="home">Home</a><span>/</span><a data-go="properties">Properties</a><span>/</span><span>' + esc(u.name) + "</span></nav>" +
      '<div class="detail"><div><div class="gal"><div class="main"><img id="gmain" src="' + img(u.imgs[0]) + '" alt="' + esc(u.name) + '"></div><div class="th">' +
      u.imgs.map((m, i) => '<button data-gi="' + i + '" class="' + (i === 0 ? "on" : "") + '" aria-label="Photo ' + (i + 1) + '"><img loading="lazy" src="' + img(m) + '" alt=""></button>').join("") + "</div></div>" +
      '<div class="dsec">' + eb("Overview") + "<p>" + (v ? "A three-level Signature Villa in " + u.rowLabel + ". The ground floor holds the foyer, majlis, living room, kitchen and a maid's suite. The first floor has the bedrooms, including the master suite, and the attic adds flexible family space. Four layout options are available; the figures here are for Layout 2."
        : "An apartment in one of the two-floor residential buildings, a short walk from the shops, the activity center and the central plaza. Type " + u.apType + " offers " + u.built + " m² of living space.") + "</p></div>" +
      '<div class="dsec">' + eb("Features") + '<ul class="plain">' + feats.map((f) => "<li>" + f + "</li>").join("") + "</ul></div>" +
      '<div class="dsec">' + eb("Floor plans") + '<div class="plan"><img loading="lazy" src="' + img(v ? "floorplan" : "apt_plan") + '" alt="Floor plan"></div><p class="note">' + (v ? "Ground, first and attic floors. Dimensions in meters. Detailed plans are shared by the sales team." : "Typical apartment layout. Detailed plans are shared by the sales team.") + "</p></div>" +
      '<div class="dsec">' + eb("Location") + '<div class="mp-scroll"><div class="mp"><img src="' + img("aerial") + '" alt="CREST CITY aerial view">' + mapSVG(v ? { highlight: u.id } : {}) + "</div></div></div></div>" +
      '<aside class="aside">' + st(u.status) + "<h1>" + esc(u.name) + '</h1><div class="cap">' + (v ? "Signature Villa · Layout options 1–4" : "Apartment · Type " + u.apType) + "</div>" + dl(facts) +
      '<div class="price"><span class="small">Price</span><b>On request</b></div>' +
      (u.status === "sold" ? '<p class="muted">This home is sold. Similar homes are listed below.</p><a class="btn full" data-go="properties" data-type="' + u.type + '">See available homes</a>'
        : '<a class="btn full" data-book="' + u.id + '">Book a visit</a><a class="btn line full" data-book="' + u.id + '">WhatsApp sales</a>') +
      '<div class="btns" style="gap:28px"><button class="tlink" data-heart="' + u.id + '">' + (wish.has(u.id) ? "Saved to shortlist" : "Save to shortlist") + '</button><button class="tlink" data-share="' + u.id + '">Share</button></div></aside></div></div>' +
      (sim.length ? carousel("c-sim", "Similar homes", "You may also like", sim.map(ucard).join("")) : "") + reg();
  };

  P.masterplan = () => {
    const V = UNITS.filter((u) => u.type === "villa");
    const cnt = (s) => V.filter((u) => u.status === s).length;
    if (!mpSel) mpSel = V.find((u) => u.status === "available").id;
    const tab = (v, t, c, n) => '<button class="' + (mpFilter === v ? "on" : "") + '" data-mpf="' + v + '">' + (c ? '<i style="background:' + c + '"></i>' : "") + t + " (" + n + ")</button>";
    return '<section class="sec"><div class="wrap"><div class="head"><div class="l">' + eb("Masterplan") + '<h1 class="h-xl">Choose your villa</h1><p class="sub">Select a villa to see its details and availability.</p></div></div>' +
      '<div class="tabs">' + tab("all", "All villas", "", V.length) + tab("available", "Available", SCOL.available, cnt("available")) + tab("reserved", "Reserved", SCOL.reserved, cnt("reserved")) + tab("sold", "Sold", SCOL.sold, cnt("sold")) + "</div>" +
      '<div class="mp-layout"><div><div class="mp-scroll"><div class="mp" id="mpmap"><img src="' + img("aerial") + '" alt="CREST CITY aerial masterplan">' + mapSVG({ filter: mpFilter, sel: mpSel, labels: true }) + '<div class="mp-tip" id="mptip" hidden></div></div></div>' +
      '<p class="note">Availability shown is illustrative for this preview. On the live site it updates when the sales team reserves or sells a villa.</p></div>' +
      '<aside class="mside" id="mpside">' + mpSide(mpSel) + "</aside></div></div></section>" +
      '<section class="sec paper"><div class="wrap feature"><div class="m"><img loading="lazy" src="' + img("commercial") + '" alt=""></div><div class="t">' + eb("Residences") + '<h2 class="h-xl">Apartments</h2><p>11 apartments in two sizes, 127 m² and 96.7 m², in two-floor residential buildings close to the shops and the activity center.</p><div><a class="btn" data-go="properties" data-type="apartment">View apartments</a></div></div></div></section>';
  };
  function mpSide(id) {
    const u = byId(id);
    return '<div class="m"><img src="' + img(u.imgs[0]) + '" alt=""></div>' + st(u.status) + "<h3>Villa " + u.code + '</h3><dl class="specs"><div><dt>Bedrooms</dt><dd>5</dd></div><div><dt>Built area</dt><dd>291.2 m²</dd></div><div><dt>Plot</dt><dd>295.2 m²</dd></div><div><dt>Location</dt><dd>' + u.rowLabel + "</dd></div></dl>" +
      '<a class="btn full" data-unit="' + u.id + '">View villa</a>' + (u.status !== "sold" ? '<a class="btn line full" data-book="' + u.id + '">Book a visit</a>' : "");
  }

  P.about = () => phero("entrance_villa", "About us", "Crest Development Group") +
    '<section class="sec"><div class="wrap feature rev"><div class="m" style="aspect-ratio:3/4"><img loading="lazy" src="' + img("villa_cover") + '" alt="Signature Villa"></div><div class="t">' + eb("Who we are") + '<h2 class="h-xl">Building homes for Djibouti\'s families</h2><p>Crest Development Group has been active in Djibouti since 2024 and was incorporated as CDG SARL in June 2026. Our first community, CREST CITY, brings family villas, apartments, shops and shared amenities together in one gated, solar-powered neighbourhood.</p><p>We design for the way families here live: a majlis for guests kept apart from family areas, space for household staff, shade and greenery outdoors, and homes built for the climate.</p></div></div></section>' +
    '<section class="sec paper"><div class="wrap"><div class="head"><div class="l">' + eb("Our promise") + '</div></div><div class="words"><div><b>Dream</b><p>Communities planned as a whole, with homes, shops, green space and services designed together from the start.</p></div><div><b>Build</b><p>Careful construction, solar energy and smart systems, with clear progress updates for every buyer.</p></div><div><b>Live</b><p>A secure, well-run community with the amenities families use every day, long after handover.</p></div></div></div></section>' +
    '<section class="sec"><div class="wrap"><div class="head"><div class="l">' + eb("Milestones") + '<h2 class="h-xl">Our journey</h2></div></div><div class="miles"><div><small>2024</small><b>Work begins in Djibouti</b><p>Crest Development Group starts preparing CREST CITY.</p></div><div><small>June 2026</small><b>Incorporated as CDG SARL</b><p>The company behind CREST CITY is formally established.</p></div><div><small>2026</small><b>Masterplan and villa designs</b><p>38 Signature Villas, apartments and a commercial street.</p></div><div><small>Next</small><b>Sales launch and construction</b><p>Buyers follow the progress of their own home online.</p></div></div></div></section>' + reg();

  P.news = () => phero("site", "News", "News and updates") +
    '<section class="sec"><div class="wrap"><p class="note" style="margin:0 0 36px">Sample articles for this preview. The Crest team publishes real updates from the content manager.</p><div class="ugrid">' + NEWS.map(story).join("") + "</div></div></section>" + reg();

  P.contact = () => {
    const today = new Date().toISOString().slice(0, 10);
    const uopts = '<option value="">Any home</option>' + UNITS.filter((u) => u.status !== "sold").map((u) => opt(u.id, u.name, contactUnit)).join("");
    return phero("villa_close", "Contact", "Book a visit or register your interest") +
      '<section class="sec"><div class="wrap contact"><div id="cwrap">' + eb("Enquiry") + '<form class="form mt-s" id="cform" novalidate>' +
      '<div class="fld"><label for="cf-name">Full name</label><input id="cf-name" autocomplete="name" required></div>' +
      '<div class="fld"><label for="cf-phone">Phone / WhatsApp</label><input id="cf-phone" type="tel" autocomplete="tel" placeholder="+253" required></div>' +
      '<div class="fld"><label for="cf-email">Email</label><input id="cf-email" type="email" autocomplete="email"></div>' +
      '<div class="fld"><label for="cf-int">Interested in</label><select id="cf-int"><option>A Signature Villa</option><option>An apartment</option><option>A commercial unit</option><option>General information</option></select></div>' +
      '<div class="fld"><label for="cf-unit">Home</label><select id="cf-unit">' + uopts + "</select></div>" +
      '<div class="fld"><label for="cf-date">Preferred visit date</label><input id="cf-date" type="date" min="' + today + '"></div>' +
      '<div class="fld full"><label for="cf-msg">Message</label><textarea id="cf-msg"></textarea></div>' +
      '<p class="full err" id="cf-err" hidden>Please enter your name and a phone number so we can reach you.</p>' +
      '<div class="full"><button class="btn" type="submit">Send request</button></div></form></div>' +
      '<div class="cinfo"><div><span class="small">Sales gallery</span><p>Avenue Mahamoud Haid, Plateau du Marabout, Djibouti</p></div><div><span class="small">Opening hours</span><p>Saturday to Thursday, 8:00–17:00</p></div>' +
      '<div><span class="small">Phone and WhatsApp</span><div class="copy"><code id="cphone">+253 XX XX XX XX</code><button data-copy="cphone">Copy</button></div></div>' +
      '<div><span class="small">Email</span><div class="copy"><code id="cmail">sales@ (to be confirmed)</code><button data-copy="cmail">Copy</button></div></div>' +
      '<p class="note">Phone and email are placeholders until The Crest confirms them.</p></div></div></section>';
  };

  P.wishlist = () => {
    const L = UNITS.filter((u) => wish.has(u.id));
    return '<section class="sec"><div class="wrap"><div class="head"><div class="l">' + eb("Your shortlist") + '<h1 class="h-xl">Saved properties</h1></div></div>' +
      (L.length ? '<div class="ugrid">' + L.map(ucard).join("") + "</div>" : '<div class="empty"><h3 class="h-l">No saved properties yet</h3><p>Use the heart on any villa or apartment to keep it here.</p><a class="btn" data-go="properties">Browse properties</a></div>') + "</div></section>";
  };

  /* ---------- router ---------- */
  const HERO = { home: 1, community: 1, properties: 1, about: 1, news: 1, contact: 1 };
  function render() {
    const isUnit = cur.indexOf("unit-") === 0;
    $("#app").innerHTML = isUnit ? P.unit(cur.slice(5).toUpperCase()) : (P[cur] || P.home)();
    document.body.dataset.hero = !isUnit && HERO[P[cur] ? cur : "home"] ? "1" : "";
    const base = isUnit ? "properties" : cur;
    $$("nav.main a").forEach((a) => a.classList.toggle("on", a.dataset.go === base));
    $$("#tabbar a").forEach((a) => a.classList.toggle("on", a.dataset.go === base));
    $("#drawer").hidden = true;
    window.scrollTo(0, 0);
    onScroll();
    startSlider();
    $$(".track").forEach(updCar);
  }
  function go(r) { cur = r; try { if (location.hash.slice(1) !== r) history.pushState(null, "", "#" + r); } catch (e) {} render(); }
  window.addEventListener("popstate", () => { cur = location.hash.slice(1) || "home"; render(); });
  window.addEventListener("hashchange", () => { const h = location.hash.slice(1) || "home"; if (h !== cur) { cur = h; render(); } });
  function onScroll() { $("#hdr").classList.toggle("solid", window.scrollY > 40); if (typeof syncStatusBar === "function") syncStatusBar(); }
  window.addEventListener("scroll", onScroll, { passive: true });
  /* ---------- hero slider ---------- */
  const DUR = 7000;
  let sIdx = 0, sEl = 0, sLast = 0, sRaf = 0;
  function startSlider() {
    cancelAnimationFrame(sRaf); sIdx = 0; sEl = 0; sLast = 0;
    if (!$("#hs")) return;
    if (reduce) paused = true;
    syncPause();
    const tick = (t) => {
      if (!$("#hs")) return;
      if (!sLast) sLast = t;
      const dt = t - sLast; sLast = t;
      if (!paused && !document.hidden) sEl += dt;
      if (sEl >= DUR) { showSlide(sIdx + 1); }
      const i = $('#hs .bar.on i'); if (i) i.style.transform = "scaleX(" + Math.min(sEl / DUR, 1) + ")";
      sRaf = requestAnimationFrame(tick);
    };
    sRaf = requestAnimationFrame(tick);
  }
  function showSlide(n) {
    const sl = $$("#hs .slide"); if (!sl.length) return;
    n = (n + sl.length) % sl.length;
    sl.forEach((el, i) => { el.classList.remove("prev"); if (i === sIdx && i !== n) el.classList.add("prev"); el.classList.toggle("on", i === n); el.setAttribute("aria-hidden", i === n ? "false" : "true"); });
    $$("#hs .bar").forEach((b, i) => { b.classList.toggle("on", i === n); b.classList.toggle("done", i < n); b.querySelector("i").style.transform = i < n ? "scaleX(1)" : "scaleX(0)"; });
    sIdx = n; sEl = 0;
    $("#slc").textContent = pad(n + 1);
  }
  function syncPause() { const b = $("#slp"); if (b) { b.innerHTML = paused ? PLAY : PAUSE; b.setAttribute("aria-label", paused ? "Play slideshow" : "Pause slideshow"); } $("#hs") && $("#hs").classList.toggle("paused", paused); }
  function updCar(t) { const n = $('[data-car="' + t.id + '"]'); if (!n) return; const [p, x] = n.querySelectorAll("button"); p.disabled = t.scrollLeft < 8; x.disabled = t.scrollLeft + t.clientWidth > t.scrollWidth - 8; }
  document.addEventListener("scroll", (e) => { if (e.target.classList && e.target.classList.contains("track")) updCar(e.target); }, true);
  function toast(t) { const el = $("#toast"); el.textContent = t; el.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => (el.hidden = true), 2600); }
  function openFilm() { const m = $("#film"), v = $("#filmv"); m.hidden = false; $("#drawer").hidden = true; wasPaused = paused; paused = true; syncPause(); v.currentTime = 0; const p = v.play(); if (p && p.catch) p.catch(() => {}); $("#filmx").focus(); }
  function closeFilm() { const v = $("#filmv"); v.pause(); $("#film").hidden = true; paused = wasPaused; syncPause(); }

  /* ---------- events ---------- */
  document.addEventListener("click", (e) => {
    const t = e.target;
    const h = t.closest("[data-heart]");
    if (h) {
      e.preventDefault(); e.stopPropagation();
      const id = h.dataset.heart;
      if (wish.has(id)) { wish.delete(id); toast("Removed from your shortlist"); } else { wish.add(id); toast("Saved to your shortlist"); }
      saveWish();
      if (typeof haptic === "function") haptic();
      $$('[data-heart="' + id + '"]').forEach((b) => { b.classList.toggle("on", wish.has(id)); if (b.classList.contains("tlink")) b.textContent = wish.has(id) ? "Saved to shortlist" : "Save to shortlist"; });
      if (cur === "wishlist") render();
      return;
    }
    if (t.closest("[data-film]")) { e.preventDefault(); openFilm(); return; }
    if (t.closest("#filmx") || t.id === "film") { closeFilm(); return; }
    if (t.closest("#slp")) { paused = !paused; syncPause(); return; }
    const sd = t.closest("[data-sdir]"); if (sd) { showSlide(sIdx + (+sd.dataset.sdir)); return; }
    const sb = t.closest("[data-sl]"); if (sb) { showSlide(+sb.dataset.sl); return; }
    const b = t.closest("[data-book]");
    if (b) { e.preventDefault(); contactUnit = b.dataset.book; go("contact"); return; }
    const u = t.closest("[data-unit]");
    if (u) { e.preventDefault(); go("unit-" + u.dataset.unit.toLowerCase()); return; }
    const g = t.closest("[data-go]");
    if (g) { e.preventDefault(); if (g.dataset.type) Object.assign(F, { type: g.dataset.type, status: "all", row: "all", size: "all" }); go(g.dataset.go); return; }
    const cn = t.closest("[data-car] button");
    if (cn) { const tr = $("#" + cn.parentNode.dataset.car); const card = tr.firstElementChild; tr.scrollBy({ left: (+cn.dataset.dir) * (card.getBoundingClientRect().width + 28), behavior: reduce ? "auto" : "smooth" }); return; }
    const gi = t.closest("[data-gi]");
    if (gi) { const u2 = byId(cur.slice(5).toUpperCase()); $("#gmain").src = img(u2.imgs[+gi.dataset.gi]); $$("[data-gi]").forEach((x) => x.classList.toggle("on", x === gi)); return; }
    const mf = t.closest("[data-mpf]");
    if (mf) { mpFilter = mf.dataset.mpf; const y = window.scrollY; render(); window.scrollTo(0, y); onScroll(); return; }
    const lot = t.closest("[data-lot]");
    if (lot) { if ($("#mpside")) selectLot(lot.dataset.lot); else go("unit-" + lot.dataset.lot.toLowerCase()); return; }
    const m = t.closest("[data-more]");
    if (m) { m.classList.toggle("open"); return; }
    const c = t.closest("[data-copy]");
    if (c) { const txt = $("#" + c.dataset.copy).textContent; try { navigator.clipboard.writeText(txt).then(() => toast("Copied"), () => selText(c.dataset.copy)); } catch (er) { selText(c.dataset.copy); } return; }
    if (t.closest("#burger")) { $("#drawer").hidden = false; return; }
    if (t.closest("#dclose")) { $("#drawer").hidden = true; return; }
    if (t.closest("#pf-reset")) { Object.assign(F, { type: "all", status: "all", row: "all", size: "all" }); render(); }
  });
  function selText(id) { const r = document.createRange(); r.selectNodeContents($("#" + id)); const s = getSelection(); s.removeAllRanges(); s.addRange(r); toast("Selected, ready to copy"); }
  function selectLot(id) {
    mpSel = id;
    $$("#mpmap .lot").forEach((g) => g.classList.toggle("sel", g.dataset.lot === id));
    const side = $("#mpside"); side.innerHTML = mpSide(id);
    if (window.innerWidth < 1100) side.scrollIntoView({ block: "nearest", behavior: reduce ? "auto" : "smooth" });
  }
  document.addEventListener("keydown", (e) => {
    const lot = e.target.closest && e.target.closest("[data-lot]");
    if (lot && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); if ($("#mpside")) selectLot(lot.dataset.lot); else go("unit-" + lot.dataset.lot.toLowerCase()); }
    if (e.target.id === "hs" && (e.key === "ArrowLeft" || e.key === "ArrowRight")) { showSlide(sIdx + (e.key === "ArrowRight" ? 1 : -1)); }
    if (e.key === "Escape") { $("#drawer").hidden = true; if (!$("#film").hidden) closeFilm(); }
  });
  document.addEventListener("mousemove", (e) => {
    const tip = $("#mptip"); if (!tip) return;
    const lot = e.target.closest && e.target.closest("#mpmap [data-lot]");
    if (!lot) { tip.hidden = true; return; }
    const u = byId(lot.dataset.lot), box = $("#mpmap").getBoundingClientRect();
    tip.textContent = "Villa " + u.code + " · " + STATUS[u.status];
    tip.style.left = e.clientX - box.left + "px"; tip.style.top = e.clientY - box.top + "px"; tip.hidden = false;
  });
  document.addEventListener("change", (e) => {
    const t = e.target;
    if (t.closest("#pfilters")) {
      F.type = $("#pf-type").value; F.status = $("#pf-status").value; F.row = $("#pf-row").value; F.size = $("#pf-size").value; F.sort = $("#pf-sort").value;
      if (F.row === "AP" && F.type === "villa") F.type = "all";
      if (ROWS.some((R) => R.r === F.row) && F.type === "apartment") F.type = "all";
      const y = window.scrollY; render(); window.scrollTo(0, y); onScroll();
    }
    if (t.id === "cf-unit") contactUnit = t.value;
  });
  document.addEventListener("submit", (e) => {
    e.preventDefault();
    const f = e.target;
    if (f.id === "hsearch") { F.type = $("#hs-type").value; F.status = $("#hs-status").value; F.size = $("#hs-size").value; F.row = "all"; go("properties"); }
    if (f.id === "fnews") { f.reset(); toast("Thank you. You are on the list for launch news."); }
    if (f.id === "cform") {
      const n = $("#cf-name").value.trim(), p = $("#cf-phone").value.trim();
      if (!n || p.replace(/\D/g, "").length < 6) { $("#cf-err").hidden = false; (n ? $("#cf-phone") : $("#cf-name")).focus(); return; }
      const u = byId($("#cf-unit").value), d = $("#cf-date").value;
      $("#cwrap").innerHTML = '<div class="done">' + eb("Request received") + '<h2 class="h-l">Thank you, ' + esc(n.split(" ")[0]) + "</h2><p>Your request" + (u ? " for " + esc(u.name) : "") + (d ? " (visit on " + esc(new Date(d + "T12:00").toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })) + ")" : "") + " is recorded in this preview.</p><p class=\"note\">On the live site, requests go straight to the sales team's CRM and the buyer receives a WhatsApp and email confirmation.</p><div><a class=\"tlink\" data-go=\"properties\">Keep browsing</a></div></div>";
      contactUnit = "";
    }
  });

  let sx = null;
  document.addEventListener("touchstart", (e) => { sx = e.target.closest && e.target.closest("#hs") ? e.touches[0].clientX : null; }, { passive: true });
  document.addEventListener("touchend", (e) => { if (sx === null) return; const dx = e.changedTouches[0].clientX - sx; if (Math.abs(dx) > 45) showSlide(sIdx + (dx < 0 ? 1 : -1)); sx = null; }, { passive: true });

  /* ---------- installable app (PWA) ---------- */
  const PWA = !!window.CREST_PWA;
  const isStandalone = () => (window.matchMedia && matchMedia("(display-mode: standalone)").matches) || navigator.standalone === true;
  const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  const isSafari = /safari/i.test(navigator.userAgent) && !/crios|fxios|edgios|chrome|android/i.test(navigator.userAgent);
  let deferredPrompt = null;
  const lsGet = (k) => { try { return localStorage.getItem(k); } catch (e) { return null; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} };
  if (PWA) {
    if (isStandalone()) document.documentElement.classList.add("standalone");
    if ("serviceWorker" in navigator) {
      window.addEventListener("load", () => { navigator.serviceWorker.register("sw.js").catch(() => {}); });
    }
    window.addEventListener("beforeinstallprompt", (e) => {
      e.preventDefault(); deferredPrompt = e;
      document.documentElement.classList.add("can-install");
      maybeShowBar(false);
    });
    window.addEventListener("appinstalled", () => { deferredPrompt = null; hideBar(); document.documentElement.classList.remove("can-install"); toast("CREST CITY is on your home screen"); });
    if (isIOS && isSafari && !isStandalone()) {
      document.documentElement.classList.add("can-install");
      setTimeout(() => maybeShowBar(true), 6000);
    }
  }
  function maybeShowBar(ios) {
    if (isStandalone()) return;
    const last = +(lsGet("crest-appbar-dismissed") || 0);
    if (Date.now() - last < 7 * 864e5) return;
    showBar(ios);
  }
  function showBar(ios) {
    const bar = $("#appbar");
    if (ios) {
      $("#appbar-msg").innerHTML = 'Tap <svg class="share" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M12 3v12M7.5 7.5 12 3l4.5 4.5"/><path d="M6 11H5v10h14V11h-1"/></svg> Share, then <b style="font-family:var(--bf);font-size:14px;letter-spacing:0;text-transform:none;font-weight:700">Add to Home Screen</b>.';
      $("#appbar-go").hidden = true;
    } else {
      $("#appbar-msg").textContent = "One tap from your home screen.";
      $("#appbar-go").hidden = false;
    }
    bar.hidden = false;
  }
  function hideBar() { const b = $("#appbar"); if (b) b.hidden = true; }
  async function doInstall() {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      try { await deferredPrompt.userChoice; } catch (e) {}
      deferredPrompt = null; hideBar();
    } else if (isIOS) { showBar(true); }
  }
  document.addEventListener("click", (e) => {
    if (e.target.closest("[data-install]")) { e.preventDefault(); $("#drawer").hidden = true; doInstall(); }
    else if (e.target.closest("#appbar-go")) { doInstall(); }
    else if (e.target.closest("#appbar-x")) { lsSet("crest-appbar-dismissed", String(Date.now())); hideBar(); }
  });

  /* ---------- native app (Capacitor) + installed-app mode ---------- */
  const SITE_URL = "https://crest-city.netlify.app/";
  const Cap = window.Capacitor;
  const NATIVE = !!(Cap && Cap.isNativePlatform && Cap.isNativePlatform());
  const NP = (Cap && Cap.Plugins) || {};
  const PLATFORM = NATIVE && Cap.getPlatform ? Cap.getPlatform() : "web";
  if (NATIVE || (PWA && isStandalone())) document.documentElement.classList.add("appmode");
  if (NATIVE) document.documentElement.classList.add("native", "p-" + PLATFORM);
  let lastBar = "";
  function syncStatusBar() {
    return; // status bar is a solid navy band on both platforms (see capacitor.config.json)
    const onImage = document.body.dataset.hero === "1" && !$("#hdr").classList.contains("solid");
    const style = onImage ? "DARK" : "LIGHT";
    if (style !== lastBar) { lastBar = style; NP.StatusBar.setStyle({ style }).catch(() => {}); }
  }
  function haptic() { if (NATIVE && NP.Haptics) NP.Haptics.impact({ style: "LIGHT" }).catch(() => {}); }
  async function shareUnit(id) {
    const u = byId(id); if (!u) return;
    const url = SITE_URL + "#unit-" + id.toLowerCase();
    const data = { title: u.name + " · CREST CITY", text: u.name + " at CREST CITY, Djibouti: " + capOf(u) + ".", url };
    try {
      if (NATIVE && NP.Share) { await NP.Share.share(Object.assign({ dialogTitle: "Share this home" }, data)); return; }
      if (navigator.share) { await navigator.share(data); return; }
    } catch (e) { if (e && e.name === "AbortError") return; }
    try { await navigator.clipboard.writeText(url); toast("Link copied"); } catch (e) { toast(url); }
  }
  document.addEventListener("click", (e) => { const b = e.target.closest("[data-share]"); if (b) { e.preventDefault(); shareUnit(b.dataset.share); } });
  if (NATIVE) {
    if (NP.StatusBar) { NP.StatusBar.setStyle({ style: "DARK" }).catch(() => {}); if (PLATFORM === "android") NP.StatusBar.setBackgroundColor({ color: "#13294B" }).catch(() => {}); }
    if (NP.App) NP.App.addListener("backButton", () => {
      if (!$("#film").hidden) { closeFilm(); return; }
      if (!$("#drawer").hidden) { $("#drawer").hidden = true; return; }
      if (cur !== "home") { if (history.length > 1) history.back(); else go("home"); }
      else NP.App.exitApp();
    });
    // Push notifications: switch on once Firebase (Android) and an APNs key (iOS) are set up.
    if (window.CREST_PUSH && NP.PushNotifications) {
      NP.PushNotifications.requestPermissions().then((p) => { if (p.receive === "granted") NP.PushNotifications.register(); }).catch(() => {});
      NP.PushNotifications.addListener("pushNotificationActionPerformed", (a) => { const r = a && a.notification && a.notification.data && a.notification.data.route; if (r) go(r); });
    }
  }

  /* ---------- boot ---------- */
  updWish();
  cur = location.hash.slice(1) || "home";
  render();
  if (NATIVE && NP.SplashScreen) setTimeout(() => NP.SplashScreen.hide().catch(() => {}), 250);
})();
